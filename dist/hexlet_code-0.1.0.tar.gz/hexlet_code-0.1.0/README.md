### Hexlet tests and linter status:
[![Actions Status](https://github.com/Zotov2003/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Zotov2003/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/479f8d0884cd9ecdd2f9/maintainability)](https://codeclimate.com/github/Zotov2003/python-project-49/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/479f8d0884cd9ecdd2f9/test_coverage)](https://codeclimate.com/github/Zotov2003/python-project-49/test_coverage)
